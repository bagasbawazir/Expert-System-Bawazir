<?php 
$conn = mysqli_connect("localhost","root","","diagnosaCabai");
 
// Check connection
if (mysqli_connect_errno()){
	echo "database connection failed : " . mysqli_connect_error();
}
 
?>