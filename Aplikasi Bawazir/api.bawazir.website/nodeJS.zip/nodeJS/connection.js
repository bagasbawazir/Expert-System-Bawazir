var mysql = require('mysql');

var con = mysql.createConnection({
  host: "SG-diagnosaCabai-2545-master.servers.mongodirector.com",
  user: "sgroot",
  password: "lxe3EYi5Q@MEedfJ",
  database: "diagnosaCabai"
});

con.connect(function (err){
    if(err) throw err;
});

module.exports = con;