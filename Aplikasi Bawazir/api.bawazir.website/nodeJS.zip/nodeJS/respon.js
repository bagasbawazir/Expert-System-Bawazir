'use strict';

exports.ok = function(values, message, res) {
  var data = {
      'status': 200,
      'message' : message,
      'values': values
  };
  res.json(data);
  res.end();
};

exports.failure = function(values,message, res) {
  var data = {
      'status': 404,
      'message': message,
      'values' : values
  };
  res.json(data);
  res.end();
};